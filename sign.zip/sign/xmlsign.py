from lxml import etree
from signxml import XMLSigner, XMLVerifier

data_to_sign = b'<?xml version="1.0" encoding="UTF-8"?><ns2:Otp xmlns:ns2="http://www.uidai.gov.in/authentication/otp/1.0" ac="public" lk="MAElpSz56NccNf11_wSM_RrXwa7n8_CaoWRrjYYWouA1r8IoJjuaGYg" sa="public" ts="2021-10-26T16:37:55" txn="test" type="A" uid="999927851557" ver="2.5"><Opts ch="01"/></ns2:Otp>'
cert = open("cer.pem").read()
key = open("key.key").read()
# load OpenSSL.crypto
# data_to_sign = "<test/>"
root = etree.fromstring(data_to_sign)
signed_root = XMLSigner().sign(root, key=key, cert=cert)
print(etree.tostring(signed_root))
# verified_data = XMLVerifier().verify(signed_root).signed_xml
# print(verified_data)